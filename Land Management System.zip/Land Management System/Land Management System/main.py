import sys
import datetime
from operationals import LandManager
from read import rent_land
from write import return_land

def main():
    print("\t ==================================== ")
    print("\t |     Techno Property Nepal       |  ")
    print("\t |            Nepal                |  ")
    print("\t |          9867865433             |  ")
    print("\t ==================================== ")
    file_path = "land_data.txt"
    land_manager = LandManager(file_path)

    while True:
        print("\nOptions:")
        print("Press 1 to show land detail :-")
        print("Press 2 to Rent Land")
        print("Press 3 to Return Land")
        print("Press 4 to Exit Program")

        choice = input("Enter your choice: ")

        if choice == '1':
            land_manager.display_land_availability()
        elif choice == '2':  # Rent Land
            while True:
                customer_name = input("Please enter the customer name: ")
                if not customer_name.isalpha():
                    print("Please enter a valid name.")
                else:
                    break  # Break out of the loop if the name is valid

            while True:
                kitta_number = input("Enter the kitta number of the land to rent: ")
                if not kitta_number.isdigit() or int(kitta_number) <= 0:
                    print("Invalid kitta number. Please enter a positive integer.")
                else:
                    kitta_number = int(kitta_number)
                    found = False
                    for land_info in land_manager.land_data:
                        if land_info['kitta_number'] == kitta_number and land_info['status'] == 'Available':
                            found = True
                            break
                    if not found:
                        print("Kitta number not found or land is not available. Please enter a valid kitta number.")
                        continue
                    break  # Break out of the loop if the number is valid and land is available

            while True:
                duration = input("Enter the duration of the rent (in months): ")
                if not duration.isdigit() or int(duration) <= 0:
                    print("Please enter a positive integer.")
                else:
                    break  # Break out of the loop if the duration is valid

            rent_land(land_manager, customer_name, kitta_number, int(duration))

        elif choice == '3':
            customer_name = input("Enter the customer name: ")
            while True:
                kitta_number = input("Enter the kitta number of the land to return: ")
                if not kitta_number.isdigit() or int(kitta_number) <= 0:
                    print("Please enter a positive integer.")
                else:
                    kitta_number = int(kitta_number)
                    found = False
                    for land_info in land_manager.land_data:
                        if land_info['kitta_number'] == kitta_number:
                            found = True
                            break
                    if not found:
                        print("Please enter a valid kitta number.")
                        continue
                    break  # Break out of the loop if the number is valid

            return_date_str = input("Enter the return date (YYYY-MM-DD HH:MM:SS): ")
            try:
                return_date = datetime.datetime.strptime(return_date_str, '%Y-%m-%d %H:%M:%S')
            except ValueError:
                print("Please enter the date in the format YYYY-MM-DD HH:MM:SS.")
                continue
            

            return_land(land_manager, customer_name, kitta_number, return_date)
        elif choice == '4':
            print("Exiting program")
            sys.exit()  
        else:
            print("Please enter a valid option.")

if __name__ == "__main__":
    main()
