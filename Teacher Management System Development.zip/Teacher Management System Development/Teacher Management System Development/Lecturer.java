public class Lecturer extends Teacher
{
    //Declaring instant varaible
    private String Department;
    private int YearsOfExperience;
    private int gradedScore; 
    private boolean hasGraded;
    int scoreGrade;
    
    public Lecturer(int teacherId, String teachername, String address,String workingtype, String employmentstatus,String department, int YearsOfExperience,int workingHours)
    {
        super(teacherId, teachername, address, workingtype, employmentstatus);
        this.Department = department;
        this.YearsOfExperience = YearsOfExperience;
        this.gradedScore = 0 ;
        this.hasGraded = false;
        setWorkingHours(workingHours);
    }
    
    //acessor method of intance variable
    public String getDepartment()
    {
        return Department;
    }
    public int getYearsOfExperience()
    {
        return YearsOfExperience;
    }
    public int getGradedScore()
    {
        return gradedScore;
    }
    public boolean gethasGraded()
    {
        return hasGraded;
    }
    
    //mutator method for graded score
    public void setGradedScore(int gradedScore)
    {
        this.gradedScore = gradedScore;
    }
    public int gradeAssignment(int gradedscore, String department, int YearsOfExperience)
    {
    if (hasGraded == false &&YearsOfExperience >= 5 && department == this.Department)
           {
                if(gradedScore >=70)
                   {
                    scoreGrade = 'A';
                   }
               else if(gradedScore >=60)
                   {
                       scoreGrade = 'B';
                   }
               else if(gradedScore >=50)
                   {
                       scoreGrade = 'C';
                   }
               else if(gradedScore >=40)
                   {
                       scoreGrade = 'D';
                   }
               else
                   {
                       scoreGrade = 'E';
                   }
                       hasGraded = true;
         }  
           return scoreGrade;
    }
    
    //Displaying the detail
    public void display()
    {
        //callinhg method from teacher
        super.display();
        System.out.println(" Department is " + getDepartment());
        System.out.println(" Years of Experience is " + getYearsOfExperience());

        if (gethasGraded() != true)
        {
            System.out.println("The Assignments have not been graded yet.");
        }
        else
        {
            System.out.println("The Assignments have been graded");
        }
    }
}
