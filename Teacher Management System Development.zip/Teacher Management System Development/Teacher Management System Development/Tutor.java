public class Tutor extends Teacher
{
    //declaring intance variable//
    private double salary;
    private String specialization;
    private String academicqualifications;
    private int performanceIndex;
    private boolean isCertified;
    
    //creating constructor with 10 parameter//
    public Tutor(int teacherId, String teachername, String address,String workingtype, String employmentstatus,int workingHours, double salary, String specialization,String academicqualifications,int performanceIndex)
    {
        super(teacherId,teachername,address,workingtype,employmentstatus);//calling contuctor of super class//
        this.salary = salary;
        this.specialization = specialization;
        this.academicqualifications = academicqualifications;
        this.performanceIndex = performanceIndex;
        this.isCertified = false;
        setWorkingHours(workingHours);
    }
    
    // accessor method//
    public double getSalary()
    {
        return this.salary;
    }
    public String getSpecialization()
    {
        return this.specialization;
    }
    public String getAcademicqualifications()
    {
        return this.academicqualifications;
    }
    public int getPerformanceIndex()
    {
        return this.performanceIndex;
    }
    public boolean getisCertified()
    {
        return this.isCertified;
    }
    
    //setter method with parameter
    public void setSalary(double newSalary, int newPerformanceIndex)
    {
        if (newPerformanceIndex >= 5 && getWorkingHours() > 20)
        {
            if (newPerformanceIndex <= 7)
            {
                this.salary = salary + (0.05 * salary);
            }
            else if (newPerformanceIndex <= 9)
            {
                this.salary = salary + (0.10 * salary);
            }
            else if (newPerformanceIndex == 10)
            {
                this.salary = salary + (0.20 * salary);
            }
           
            this.isCertified = true;
        }
       
        else
        {
            System.out.println("Salary cannot be approved");
        }
    }
    
    //creating removetutor method//
    public void removeTutor()
    {
        if (this.isCertified != true)
        {
            this.salary = 0;
            this.specialization = "";
            this.academicqualifications = "";
            this.performanceIndex = 0;
        }
        this.isCertified = false;
    }
    
    //displaying
       public void display()
    {  
       if(isCertified = false)
       {
        super.display();
       }
       
       else
       {
        super.display();//calling display method from super class
        System.out.println("Salary :" +getSalary());
        System.out.println("Specialization:" +getSpecialization());
        System.out.println("Academic Qualifiaction:" +getAcademicqualifications());
        System.out.println("PerformenceIndex:" +getPerformanceIndex());
       }
    }
}
