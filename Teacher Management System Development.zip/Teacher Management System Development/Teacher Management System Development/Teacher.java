public class Teacher
{
    // declaring instance variable//
    private int teacherId; 
    private String teachername; 
    private String address;            
    private String workingtype;       
    private String employmentstatus;      
    private int workinghours;
    
    //constructors with parameter//
    public Teacher(int teacherId, String teachername, String address,String workingtype, String employmentstatus)
    {
        this.teacherId = teacherId;
        this.teachername = teachername;
        this.address = address;
        this.workingtype = workingtype;
        this.employmentstatus = employmentstatus;
    }
    
    //accesor method//
    public int getTeacherId()
    {
        return this.teacherId;
    }

    public String getTeacherName()
    {
        return this.teachername;
    }

    public String getAddress()
    {
        return this.address;
    }

    public String getWorkingType()
    {
        return this.workingtype;
    }

    public String getEmploymentStatus()
    {
        return this.employmentstatus;
    }

    public int getWorkingHours()
    {
        return this.workinghours;
    }
    
    //mutator method//
       public void setWorkingHours(int workingHours)
    {
        this.workinghours = workingHours;
    }
    
    //displaying the code//
     public void display()
     {
        System.out.println("The Teacher Id is " + getTeacherId());
        System.out.println("The Teacher Name is " + getTeacherName());
        System.out.println("The Address is " + getAddress());
        System.out.println("The Working Type is " + getWorkingType());
        System.out.println("The Employment Status is " + getEmploymentStatus());
        
        if (workinghours == 0)
        {
            System.out.println("The Working hours have not been assgined");
        }
        else
        {
            System.out.println("The Working hours is " + getWorkingHours());
        }
    }
}
